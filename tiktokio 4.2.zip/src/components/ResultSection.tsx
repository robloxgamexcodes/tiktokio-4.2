// src/components/ResultSection.tsx
import { openDirectLink } from "./directLink";
import ResultAd, { triggerResultAdClick } from "./ResultAd";

interface ResultSectionProps {
  data: {
    status: string | null;
    result: {
      type: string | null;
      author: {
        avatar: string | null;
        nickname: string | null;
      } | null;
      desc: string | null;
      videoSD: string | null;
      videoHD: string | null;
      video_hd: string | null;
      videoWatermark: string | null;
      music: string | null;
      uploadDate?: string | null;
      thumbnail?: string | null;
      views?: number;
      likes?: number;
      comments?: number;
      shares?: number;
    } | null;
  };
  getVideoUrl: () => string;
  getAuthorInfo: () => { avatar: string; nickname: string };
  getSafeFilename: () => string;
  onDownloadClick: (downloadUrl: string, filename: string) => void;
}

function ResultSection(props: ResultSectionProps) {
  console.log("🎨 ResultSection rendering");
  console.log("📦 Props data:", props.data);
  console.log("📊 Result stats:", {
    views: props.data?.result?.views,
    likes: props.data?.result?.likes,
    comments: props.data?.result?.comments,
    shares: props.data?.result?.shares,
    avatar: props.data?.result?.author?.avatar
  });

  if (!props.data || !props.data.result) {
    console.log("❌ No data or result, returning null");
    return null;
  }

  const result = props.data.result;

  // ─── Helpers ─────────────────────────────────────────────────────────────

  // Generate filename based on type
  const generateFilename = (baseName: string, type: 'video' | 'audio' | 'watermark' | 'avatar' | 'thumbnail') => {
    let filename = (baseName || 'tiktok-video').trim();

    if (type === 'audio') {
      filename += '_audio';
    } else if (type === 'watermark') {
      filename += '_watermark';
    } else if (type === 'avatar') {
      filename += '_avatar';
    } else if (type === 'thumbnail') {
      filename += '_thumbnail';
    }

    if (!filename.startsWith('tiktokio.cam')) {
      filename = `tiktokio.cam_${filename}`;
    }

    if (type === 'avatar' || type === 'thumbnail') {
      if (!filename.toLowerCase().endsWith('.jpg')) filename += '.jpg';
    } else if (type === 'audio') {
      if (!filename.toLowerCase().endsWith('.mp3')) filename += '.mp3';
    } else {
      if (!filename.toLowerCase().endsWith('.mp4')) filename += '.mp4';
    }

    return filename;
  };

  // Wrapper: engage ad + direct link, then run the real download handler from parent
  const handleDownload = (downloadUrl: string, filename: string) => {
    triggerResultAdClick();
    // openDirectLink is already called inside the parent onDownloadClick / handleDownloadClick
    props.onDownloadClick(downloadUrl, filename);
  };

  // Download avatar via same-origin proxy (/api/download) and verify the bytes
  const downloadAvatar = async (e: Event) => {
    e.preventDefault();
    e.stopPropagation();
    openDirectLink(); // must run before the first await to avoid popup blocking
    triggerResultAdClick(); // also engage the result ad

    const avatarUrl = props.getAuthorInfo().avatar;
    if (!avatarUrl) {
      console.error("No avatar URL available");
      return;
    }

    const finalFilename = generateFilename(props.getSafeFilename(), 'avatar');
    const proxyUrl = `/api/download.json?url=${encodeURIComponent(avatarUrl)}&type=.jpg&title=${encodeURIComponent(finalFilename)}`;

    try {
      const res = await fetch(proxyUrl);
      if (!res.ok) {
        let detail = `HTTP ${res.status}`;
        try { const j = await res.json(); detail = `${j.error || detail}${j.reason ? ` (${j.reason})` : ''}${j.host ? ` [${j.host}]` : ''}`; } catch {}
        throw new Error(detail);
      }
      const blob = await res.blob();
      if (!blob.size) throw new Error("Empty file received");

      const ext = blob.type.includes("png") ? ".png" : blob.type.includes("webp") ? ".webp" : ".jpg";
      const name = finalFilename.replace(/\.[a-z0-9]{2,4}$/i, "") + ext;

      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = name;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => { document.body.removeChild(link); URL.revokeObjectURL(objectUrl); }, 1000);
    } catch (err) {
      console.error("Avatar download failed:", err);
      alert(`Could not download the profile picture.\n${(err as Error).message}`);
    }
  };

  // Download video thumbnail via same-origin proxy (/api/download.json) and verify the bytes
  const downloadThumbnail = async (e: Event) => {
    e.preventDefault();
    e.stopPropagation();
    openDirectLink(); // must run before the first await to avoid popup blocking
    triggerResultAdClick(); // also engage the result ad

    const thumbUrl = result.thumbnail;
    if (!thumbUrl) {
      console.error("No thumbnail URL available");
      return;
    }

    const finalFilename = generateFilename(props.getSafeFilename(), 'thumbnail');
    const proxyUrl = `/api/download.json?url=${encodeURIComponent(thumbUrl)}&type=.jpg&title=${encodeURIComponent(finalFilename)}`;

    try {
      const res = await fetch(proxyUrl);
      if (!res.ok) {
        let detail = `HTTP ${res.status}`;
        try { const j = await res.json(); detail = `${j.error || detail}${j.reason ? ` (${j.reason})` : ''}${j.host ? ` [${j.host}]` : ''}`; } catch {}
        throw new Error(detail);
      }
      const blob = await res.blob();
      if (!blob.size) throw new Error("Empty file received");

      const ext = blob.type.includes("png") ? ".png" : blob.type.includes("webp") ? ".webp" : ".jpg";
      const name = finalFilename.replace(/\.[a-z0-9]{2,4}$/i, "") + ext;

      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = name;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => { document.body.removeChild(link); URL.revokeObjectURL(objectUrl); }, 1000);
    } catch (err) {
      console.error("Thumbnail download failed:", err);
      alert(`Could not download the thumbnail.\n${(err as Error).message}`);
    }
  };

  // Stats with defaults
  const views    = result.views    || 0;
  const likes    = result.likes    || 0;
  const comments = result.comments || 0;
  const shares   = result.shares   || 0;

  const thumbnail  = result.thumbnail;
  const authorInfo = props.getAuthorInfo();
  const avatarUrl  = authorInfo.avatar;

  console.log("🖼️ Thumbnail URL:", thumbnail);
  console.log("👤 Avatar URL:", avatarUrl);
  console.log("👤 Full avatar object:", props.data.result.author);

  const handleAvatarError = (e: Event) => {
    const img = e.currentTarget as HTMLImageElement;
    console.error("❌ Avatar failed to load:", avatarUrl);
    if (img.hasAttribute('referrerpolicy')) {
      img.removeAttribute('referrerpolicy');
      img.removeAttribute('crossorigin');
      const src = img.src;
      img.src = '';
      img.src = src;
    } else {
      img.style.display = 'none';
    }
  };

  return (
    <div class="py-8">
      <div class="mt-4 max-w-6xl mx-auto">
        <div
          class="relative rounded-lg overflow-hidden border border-white/10 p-4"
          style={{ minHeight: '500px' }}
        >
          {/* Background Image */}
          {thumbnail && (
            <>
              <img
                src={thumbnail}
                alt="background"
                class="absolute top-0 left-0 w-full h-full object-cover"
                style={{ zIndex: 1, pointerEvents: 'none' }}
                onLoad={() => console.log("✅ Background image loaded")}
                onError={(e) => {
                  console.error("❌ Background image failed to load");
                  e.currentTarget.style.display = 'none';
                }}
              />
              {/* White overlay */}
              <div
                class="absolute top-0 left-0 w-full h-full bg-white"
                style={{ zIndex: 2, opacity: 0.5, pointerEvents: 'none' }}
              />
            </>
          )}

          {/* Content Layer */}
          <div class="relative" style={{ zIndex: 10 }}>
            <div class="flex flex-col md:flex-row gap-4">
              {/* Left Column - Video Preview */}
              <div class="md:w-1/3 flex-shrink-0">
                <div class="relative rounded-lg overflow-hidden max-h-[430px] bg-black">
                  {props.getVideoUrl() && (
                    <video
                      controls
                      src={props.getVideoUrl()}
                      class="w-full h-full object-cover"
                      referrerpolicy="no-referrer"
                    >
                      Your browser does not support the video tag.
                    </video>
                  )}
                </div>
              </div>

              {/* Right Column - Author Info, Stats, Ad Banner & Download Buttons */}
              <div class="md:w-2/3 flex flex-col justify-between">
                <div class="mb-3">
                  {/* Author Info with Avatar Download */}
                  <div class="flex items-center gap-3 mb-4">
                    {avatarUrl ? (
                      <div class="relative group">
                        <img
                          src={avatarUrl}
                          alt={authorInfo.nickname}
                          class="rounded-full w-20 h-20 object-cover border-2 border-gray-300 shadow-md"
                          referrerpolicy="no-referrer"
                          crossorigin="anonymous"
                          onLoad={() => console.log("✅ Avatar loaded successfully:", avatarUrl)}
                          onError={handleAvatarError}
                        />
                        {/* Download button overlay */}
                        <button
                          onClick={downloadAvatar}
                          class="absolute inset-0 flex items-center justify-center rounded-full transition-all duration-200 cursor-pointer"
                          title="Download profile picture"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                        </button>
                      </div>
                    ) : (
                      <div class="rounded-full w-20 h-20 bg-gray-300 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                      </div>
                    )}
                    <div>
                      <h2 class="text-xl font-bold text-gray-900">
                        {authorInfo.nickname}
                      </h2>
                      {avatarUrl && (
                        <button
                          onClick={downloadAvatar}
                          class="text-sm text-blue-600 hover:text-blue-800 underline mt-1 flex items-center gap-1"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                          Download Profile Picture
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Description */}
                  <div class="text-gray-900 text-base mb-4 bg-white/70 p-3 rounded-lg">
                    {result.desc || "No description available"}
                  </div>

                  {/* Stats Section */}
                  {(views > 0 || likes > 0 || comments > 0 || shares > 0) && (
                    <div class="bg-[#1a2332] rounded-lg py-4 px-3 mb-4">
                      <div class="flex items-center justify-around">
                        {/* Views */}
                        {views > 0 && (
                          <div class="flex flex-col items-center gap-1">
                            <svg aria-label="Views" class="flex-shrink-0" fill="#00d4ff" height="24" role="img" viewBox="0 0 24 24" width="24">
                              <title>Views</title>
                              <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"></path>
                            </svg>
                            <span class="font-bold text-white text-base">{views >= 1000000 ? (views / 1000000).toFixed(1) + 'M' : views >= 1000 ? (views / 1000).toFixed(1) + 'K' : views.toLocaleString()}</span>
                            <span class="text-gray-400 text-xs">Views</span>
                          </div>
                        )}

                        {/* Likes */}
                        {likes > 0 && (
                          <div class="flex flex-col items-center gap-1">
                            <svg aria-label="Like" class="flex-shrink-0" fill="#ff0050" height="24" role="img" viewBox="0 0 24 24" width="24">
                              <title>Like</title>
                              <path d="M16.792 3.904A4.989 4.989 0 0 1 21.5 9.122c0 3.072-2.652 4.959-5.197 7.222-2.512 2.243-3.865 3.469-4.303 3.752-.477-.309-2.143-1.823-4.303-3.752C5.141 14.072 2.5 12.167 2.5 9.122a4.989 4.989 0 0 1 4.708-5.218 4.21 4.21 0 0 1 3.675 1.941c.84 1.175.98 1.763 1.12 1.763s.278-.588 1.11-1.766a4.17 4.17 0 0 1 3.679-1.938m0-2a6.04 6.04 0 0 0-4.797 2.127 6.052 6.052 0 0 0-4.787-2.127A6.985 6.985 0 0 0 .5 9.122c0 3.61 2.55 5.827 5.015 7.97.283.246.569.494.853.747l1.027.918a44.998 44.998 0 0 0 3.518 3.018 2 2 0 0 0 2.174 0 45.263 45.263 0 0 0 3.626-3.115l.922-.824c.293-.26.59-.519.885-.774 2.334-2.025 4.98-4.32 4.98-7.94a6.985 6.985 0 0 0-6.708-7.218Z"></path>
                            </svg>
                            <span class="font-bold text-white text-base">{likes >= 1000000 ? (likes / 1000000).toFixed(1) + 'M' : likes >= 1000 ? (likes / 1000).toFixed(1) + 'K' : likes.toLocaleString()}</span>
                            <span class="text-gray-400 text-xs">Likes</span>
                          </div>
                        )}

                        {/* Comments */}
                        {comments > 0 && (
                          <div class="flex flex-col items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                              <g fill="none" stroke="#19ac05" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                                <title>Comment</title>
                                <path fill="#19ac05" d="M17 12.5a.5.5 0 1 0 0-1a.5.5 0 0 0 0 1m-5 0a.5.5 0 1 0 0-1a.5.5 0 0 0 0 1m-5 0a.5.5 0 1 0 0-1a.5.5 0 0 0 0 1"/>
                                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2S2 6.477 2 12c0 1.821.487 3.53 1.338 5L2.5 21.5l4.5-.838A9.96 9.96 0 0 0 12 22"/>
                              </g>
                            </svg>
                            <span class="font-bold text-white text-base">{comments >= 1000000 ? (comments / 1000000).toFixed(1) + 'M' : comments >= 1000 ? (comments / 1000).toFixed(1) + 'K' : comments.toLocaleString()}</span>
                            <span class="text-gray-400 text-xs">Comments</span>
                          </div>
                        )}

                        {/* Shares */}
                        {shares > 0 && (
                          <div class="flex flex-col items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                              <title>Share</title>
                              <path fill="#0089ff" d="m13.12 17.023l-4.199-2.29a4 4 0 1 1 0-5.465l4.2-2.29a4 4 0 1 1 .958 1.755l-4.2 2.29a4 4 0 0 1 0 1.954l4.2 2.29a4 4 0 1 1-.959 1.755M6 14a2 2 0 1 0 0-4a2 2 0 0 0 0 4m11-6a2 2 0 1 0 0-4a2 2 0 0 0 0 4m0 12a2 2 0 1 0 0-4a2 2 0 0 0 0 4"/>
                            </svg>
                            <span class="font-bold text-white text-base">{shares >= 1000000 ? (shares / 1000000).toFixed(1) + 'M' : shares >= 1000 ? (shares / 1000).toFixed(1) + 'K' : shares.toLocaleString()}</span>
                            <span class="text-gray-400 text-xs">Shares</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Download Profile Picture (between stats and download buttons) */}
                {avatarUrl && (
                  <button
                    class="download-button bg-pink-600 hover:bg-pink-700 w-full p-3 rounded text-white font-bold flex items-center justify-center cursor-pointer transition-colors mb-4"
                    onClick={downloadAvatar}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                    </svg>
                    Download Profile Picture
                  </button>
                )}

                {/* Ad – right after the Download Profile Picture button */}
                {avatarUrl && <ResultAd />}


                {/* ── Download Buttons ─────────────────────────────────────────── */}
                <div class="space-y-2">
                  {/* Download SD */}
                  {result.videoSD && (
                    <button
                      class="download-button bg-amber-600 hover:bg-amber-700 w-full p-3 rounded text-white font-bold flex items-center justify-center cursor-pointer transition-colors"
                      onClick={() => handleDownload(
                        `https://dl.tiktokiocdn.workers.dev/api/download?url=${encodeURIComponent(result.videoSD!)}&type=.mp4&title=${props.getSafeFilename()}`,
                        generateFilename(props.getSafeFilename(), 'video')
                      )}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                      </svg>
                      Download SD (No Watermark)
                    </button>
                  )}

                  {/* Download HD */}
                  {(result.videoHD || result.video_hd) && (
                    <button
                      class="download-button bg-amber-600 hover:bg-amber-700 w-full p-3 rounded text-white font-bold flex items-center justify-center cursor-pointer transition-colors"
                      onClick={() => handleDownload(
                        `https://dl.tiktokiocdn.workers.dev/api/download?url=${encodeURIComponent((result.videoHD || result.video_hd)!)}&type=.mp4&title=${props.getSafeFilename()}`,
                        generateFilename(props.getSafeFilename(), 'video')
                      )}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                      </svg>
                      Download HD (No Watermark)
                    </button>
                  )}

                  {/* Download with Watermark */}
                  {result.videoWatermark && (
                    <button
                      class="download-button bg-blue-600 hover:bg-blue-700 w-full p-3 rounded text-white font-bold flex items-center justify-center cursor-pointer transition-colors"
                      onClick={() => handleDownload(
                        `https://dl.tiktokiocdn.workers.dev/api/download?url=${encodeURIComponent(result.videoWatermark!)}&type=.mp4&title=${props.getSafeFilename()}`,
                        generateFilename(props.getSafeFilename(), 'watermark')
                      )}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                      </svg>
                      Download (With Watermark)
                    </button>
                  )}

                  {/* Download Audio */}
                  {result.music && (
                    <button
                      class="download-button bg-purple-600 hover:bg-purple-700 w-full p-3 rounded text-white font-bold flex items-center justify-center cursor-pointer transition-colors"
                      onClick={() => handleDownload(
                        `https://dl.tiktokiocdn.workers.dev/api/download?url=${encodeURIComponent(result.music!)}&type=.mp3&title=${props.getSafeFilename()}_audio`,
                        generateFilename(props.getSafeFilename(), 'audio')
                      )}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"></path>
                      </svg>
                      Download Audio Only
                    </button>
                  )}

                  {/* Download Thumbnail */}
                  {result.thumbnail && (
                    <button
                      class="download-button bg-teal-600 hover:bg-teal-700 w-full p-3 rounded text-white font-bold flex items-center justify-center cursor-pointer transition-colors"
                      onClick={downloadThumbnail}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                      </svg>
                      Download Thumbnail
                    </button>
                  )}

                  {/* Download Another */}
                  <button
                    class="download-button bg-gray-700 hover:bg-gray-800 w-full p-3 rounded text-white font-bold flex items-center justify-center cursor-pointer transition-colors"
                    onClick={() => window.location.href = '/'}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                    </svg>
                    Download Another Video
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ResultSection;